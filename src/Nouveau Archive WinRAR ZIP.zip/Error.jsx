import React, { useEffect } from "react";

const Error = () => {
    useEffect(() => {
        // Vérifie si Webflow est chargé et relance les animations
        if (window.Webflow) {
            window.Webflow.destroy(); // Réinitialise Webflow pour éviter des conflits
            window.Webflow.ready(); // Recharge les animations et interactions
            window.Webflow.require("ix2").init(); // Réactive les animations Webflow (IX2)
        }
    }, []);

    return (
        <div>
            <div className="_404-logo-wrapper">
                <a href="/" className="w-nav-brand">
                    <img
                        src="/images/logo.jpg"
                        loading="lazy"
                        sizes="(max-width: 1279px) 30px, (max-width: 1439px) 2vw, 200px"
                        height="100px"
                        alt="Logo"
                        srcSet="/images/logo-p-500.jpg 500w, /images/logo-p-800.jpg 800w, /images/logo.jpg 1024w"
                    />
                </a>
            </div>
            <div className="utility-page-wrap black-background">
                <div className="_404-block">
                    <div className="_404-text text-color-white">404</div>
                </div>
                <div className="_404-content-wrapper">
                    <h2 className="text-center text-color-white">Il n'y a rien ici !</h2>
                    <p className="_404-paragraph text-color-white">
                        Nous n'avons pas trouvé la page que vous cherchez.
                    </p>
                    <a href="/" className="primary-button-white w-button">
                        Retourner à l'accueil
                    </a>
                </div>
            </div>
        </div>
    );
};

export default Error;
