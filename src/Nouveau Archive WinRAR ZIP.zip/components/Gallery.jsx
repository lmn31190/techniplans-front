import * as React from "react";
import Box from "@mui/material/Box";
import ImageList from "@mui/material/ImageList";
import ImageListItem from "@mui/material/ImageListItem";
import ImageListItemBar from "@mui/material/ImageListItemBar";
import Lightbox from "./Lightbox"; // Import du composant Lightbox

const Gallery = ({ images = [] }) => {
  const [lightboxOpen, setLightboxOpen] = React.useState(false);
  const [selectedIndex, setSelectedIndex] = React.useState(0);

  // Fonction pour ouvrir le Lightbox
  const openLightbox = (index) => {
    setSelectedIndex(index);
    setLightboxOpen(true);
  };

  // Fonction pour fermer le Lightbox
  const closeLightbox = () => {
    setLightboxOpen(false);
  };

  // Passer à l'image suivante (Boucle)
  const nextImage = () => {
    setSelectedIndex((prevIndex) => (prevIndex + 1) % images.length);    
  };

  // Passer à l'image précédente (Boucle)
  const prevImage = () => {
    setSelectedIndex((prevIndex) => (prevIndex === 0 ? images.length - 1 : prevIndex - 1));
  };

  // Appliquer les tailles en fonction des lignes paires et impaires
  const arrangedImages = React.useMemo(() => {
    return images.map((imgUrl, index) => {
      const row = Math.floor(index / 3); // Identifier la ligne
      const column = index % 3; // Identifier la position dans la ligne

      let height;
      if (row % 2 === 0) {
        // Lignes paires : [285.08, 601.98, 285.08]
        height = column === 1 ? 601.98 : 285.08;
      } else {
        // Lignes impaires : [601.98, 285.08, 601.98]
        height = column === 0 || column === 2 ? 601.98 : 285.08;
      }

      return { url: imgUrl, height };
    });
  }, [images]);

  return (
    <>
      <Box sx={{ width: "100%", height: "auto", overflowY: "scroll", marginTop: "20px", padding: "10px" }}>
        <ImageList variant="masonry" cols={3} gap={8}>
          {arrangedImages.map((item, index) => (
            <ImageListItem key={index} sx={{ borderRadius: "10px", overflow: "hidden", cursor: "pointer" }}>
              <img
                src={item.url}
                alt={`Image ${index + 1}`}
                loading="lazy"
                style={{
                  width: "100%",
                  height: `${item.height}px`,
                  objectFit: "cover",
                  display: "block",
                  borderRadius: "10px",
                  boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
                  transition: "transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out",
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.transform = "scale(1.05)";
                  e.currentTarget.style.boxShadow = "0px 8px 16px rgba(0, 0, 0, 0.2)";
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = "scale(1)";
                  e.currentTarget.style.boxShadow = "0px 4px 6px rgba(0, 0, 0, 0.1)";
                }}
                onClick={() => openLightbox(index)} // Ouvre le Lightbox au clic
              />
              <ImageListItemBar position="below" title={`Image ${index + 1}`} />
            </ImageListItem>
          ))}
        </ImageList>
      </Box>

      {/* Affichage du Lightbox si ouvert */}
      {lightboxOpen && (
        <Lightbox
          images={images}
          selectedIndex={selectedIndex}
          onClose={closeLightbox}
          onNext={nextImage}
          onPrev={prevImage}
        />
      )}
    </>
  );
}


export default Gallery;