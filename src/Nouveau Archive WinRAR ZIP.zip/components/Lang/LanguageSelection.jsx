import React, { useState } from "react";
import "./languageSelection.css"; // Ajoute un fichier CSS pour le style
import Contact from "../../Pages/Contact";
import ContactEN from "../../Pages/ContactEN";

const LanguageSelection = () => {
  const [selectedLanguage, setSelectedLanguage] = useState(null); // État pour stocker la langue choisie

  return (
    <div className="language-selection-container">
      {selectedLanguage === null ? ( 
        <div className="language-choice">
          <h2>Choisissez votre langue / Choose your language</h2>
          <div className="button-container">
            <button className="btn lang-btn" onClick={() => setSelectedLanguage("fr")}>
              🇫🇷 Français
            </button>
            <button className="btn lang-btn" onClick={() => setSelectedLanguage("en")}>
              🇬🇧 English
            </button>
          </div>
        </div>
      ) : selectedLanguage === "fr" ? window.location.href = "/contact": window.location.href = "/contact-en"}
    </div>
  );
};

export default LanguageSelection;
