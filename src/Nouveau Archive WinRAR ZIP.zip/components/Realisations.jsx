import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const Realisations = () => {
  const [realisations, setRealisations] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(2);
  const sliderMaskRef = useRef(null);

  useEffect(() => {
    axios.get("http://localhost:5000/api/realisations")
      .then(res => setRealisations(res.data))
      .catch(err => console.error("Erreur lors du chargement :", err));
  }, []);

  const scrollCarousel = (direction) => {
    if (!sliderMaskRef.current || realisations.length === 0) return;
    
    let newIndex = direction === "right" ? currentIndex + 1 : currentIndex - 1;
    if (newIndex < 0) newIndex = realisations.length - 1;
    if (newIndex >= realisations.length) newIndex = 0;
    
    setCurrentIndex(newIndex);
  };

  return (
    <section id="realisations" className="section black-background">
      <div className="base-container w-container">
        <div className="section-title-wrapper">
          <p className="subtitle text-white-color">Mes réalisations</p>
          <h2 className="text-white-color">Partout dans le monde</h2>
        </div>
        <div className="slider-wrapper" style={{ overflow: "hidden", position: "relative" }}>
          
          <div className="projects-card-slider w-slider">
            <div
              className="projects-mask w-slider-mask"
              ref={sliderMaskRef}
              style={{
                display: "flex",
                transition: "transform 0.5s ease-in-out",
                transform: `translateX(-${currentIndex * 100}%)`
              }}
            >
              {realisations.length > 0 ? (
                realisations.map((realisation) => (
                  <div key={realisation._id} className="project-slide w-slide" style={{ minWidth: "100%" }}>
                    <Link to={`/realisation/${realisation._id}`} className="project-card-wrapper w-inline-block">
                      <div className="project-image-wrapper">
                        <div className="project-image">
                          <img src={realisation.imageUrl} alt={realisation.title} />
                          <div className="gradient-overlay" />
                          <div className="background-load-top dark-color" />
                          <div className="background-load-bottom dark-color" />
                        </div>
                      </div>
                      <div className="project-content">
                        <div className="project-card-bottom">
                          <div className="text-content">
                            <p className="subtitle-category text-white-color">{realisation.category}</p>
                          </div>
                          <h3 className="text-white-color">{realisation.title}</h3>
                        </div>
                      </div>
                    </Link>
                  </div>
                ))
              ) : (
                <p>Rien</p>
              )}
            </div>
          </div>
          <button className="slide-arrow w-slider-arrow-left" onClick={() => scrollCarousel("left")} style={{ position: "absolute", top: "65%", left: "25%", zIndex: 10, background: "rgba(0,0,0,0.5)", cursor: "pointer", transform: 'translate(-25%, 50%)' }}>
            <img alt="Left Arrow" src="images/Left-Arrow.png" className="image-10" />
          </button>
          <button className="slide-arrow right w-slider-arrow-right" onClick={() => scrollCarousel("right")} style={{ position: "absolute", top: "65%", right: "10px", zIndex: 10, background: "rgba(0,0,0,0.5)", cursor: "pointer", transform: 'translate(-25%, 50%)' }}>
            <img alt="Right Arrow" src="images/Right-Arrow.png" className="image-9" />
          </button>
          <div className="slide-nav-none w-slider-nav w-round"></div>
        </div>
      </div>
    </section>
  );
};

export default Realisations;
