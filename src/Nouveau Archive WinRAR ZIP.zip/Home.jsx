import React from 'react'
import Hero from '../components/Hero';
import About from '../components/About';
import Steps from '../components/Steps';
import Services from '../components/Services';
import Realisations from '../components/Realisations';
import SliderImg from '../components/SliderImg';

const Home = () => {
    return (
        <div>
            <Hero />
            <About />
            <Steps />
            <Services />
            <Realisations />
            <SliderImg />
        </div>
    )
}

export default Home