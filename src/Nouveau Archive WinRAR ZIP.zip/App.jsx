import React, { useEffect, useState } from 'react';
import { Route, Routes, useLocation, Navigate } from 'react-router-dom';
import Home from './Pages/Home';
import Contact from './Pages/Contact';
import Error from './Pages/Error';
import RealisationDetail from "./Pages/RealisationDetail";
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import LanguageSelection from './components/Lang/LanguageSelection';
import ContactEN from './Pages/ContactEN';

const App = () => {
  const location = useLocation(); // Détecte l'URL actuelle
  const [isErrorPage, setIsErrorPage] = useState(false);

  useEffect(() => {
    // ✅ Détecte si on est sur la page 404 (grâce à l'URL)
    setIsErrorPage(location.pathname === "/404");

    setTimeout(() => {
      if (typeof window.Webflow !== "undefined" && typeof window.Webflow.require === "function") {
        console.log("🔄 Webflow rechargé après changement de page :", location.pathname);
        try {
          window.Webflow.require("ix2").init(); // Recharge les animations
        } catch (error) {
          console.error("⚠️ Erreur lors de la réinitialisation de Webflow :", error);
        }
      } else {
        console.warn("⚠️ Webflow n'est pas encore chargé.");
      }
    }, 500);
  }, [location]);

  const isContactPage = location.pathname === "/contact" || location.pathname === "/contact-en";

  return (
    <div>

{!isErrorPage && !isContactPage && <Navbar />}
      
      <Routes>
        <Route index element={<Home />} />
        <Route path='/language' element={<LanguageSelection />}/>
        <Route path='/contact' element={<Contact />}/>
        <Route path='/contact-en' element={<ContactEN />}/>
        <Route path='/realisation/:id' element={<RealisationDetail />} />
        <Route path='/404' element={<Error />} />
        <Route path="*" element={<Navigate to="/404" replace />} />
      </Routes>

      {!isErrorPage && !isContactPage && <Footer />}
    </div>
  );
};

export default App;
